package myApp;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.*;

import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;

@Path("/footballteam")
public class FootballResource {

	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.TEXT_XML })
	public List<Football> alldata() {
		return FootballDAO.INSTANCE.getalldetails();
	}

	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.TEXT_XML })
	@Path("{playerNAME}")
	public List<Football> getPlayerName(@PathParam("playerNAME") String name) throws ClassNotFoundException {
		return FootballDAO.INSTANCE.getPlayerName(name);
	}

	@POST
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Path("/{foottballdata}")
	public String postThreeMoblie(@FormParam("name") String name, @FormParam("gamesplayed") String gamesplayed,
			@FormParam("goalsscored") String goalsscored, @FormParam("jerseynumber") String jerseynumber,
			@Context HttpServletResponse httpServletResponse) {
		return FootballDAO.INSTANCE.insertdetails(name, gamesplayed, goalsscored, jerseynumber);
	}

	@DELETE
	@Produces(MediaType.TEXT_HTML)
	@Path("/{footballid}")
	public String deleteMoblieByID(@PathParam("footballid") String id) throws ClassNotFoundException {
		return FootballDAO.INSTANCE.deletebyname(id);
	}

	@DELETE
	@Produces(MediaType.TEXT_HTML)
	public String deleteAllMoblie() throws ClassNotFoundException {
		return FootballDAO.INSTANCE.deleteallfootball();
	}

	@PUT
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Path("/{footballupdate}")
	public String putMoblie(@PathParam("footballupdate") String id, @FormParam("name") String name,
			@FormParam("gamesplayed") String gamesplayed, @FormParam("goalsscored") String goalsscored,
			@FormParam("jerseynumber") String jerseynumber, @Context HttpServletResponse servletResponse)
			throws ClassNotFoundException {
		return FootballDAO.INSTANCE.updatefootballdata(id, name, gamesplayed, goalsscored, jerseynumber);
	}
}
