package myApp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public enum FootballDAO {
	INSTANCE;

	private List<Football> playersList;

	public String insertdetails(String name, String gamesplayed, String goalsscored, String jerseynumber) {

		try {
			Class.forName("org.hsqldb.jdbcDriver");
			Connection con = (Connection) DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/onedb", "SA", "");

			PreparedStatement fprd = con.prepareStatement("INSERT INTO FOOTBALL (name, jerseynumber) VALUES (?,?)");
			fprd.setString(1, name);
			fprd.setString(2, jerseynumber);

			PreparedStatement spred = con.prepareStatement("INSERT INTO STATS (gamesplayed,goalsscored) VALUES (?,?)");
			spred.setString(1, gamesplayed);
			spred.setString(2, goalsscored);
			spred.execute();

			if ((fprd.execute())) {
				return "Error with Inserting Data";
			} else {
				return "Insert Data Successfully";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Insert Data Successfully";
	}

	public List<Football> getalldetails() {
		List<Football> data = new ArrayList<Football>();
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			Connection con = (Connection) DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/onedb", "SA", "");

			PreparedStatement prd = con.prepareStatement(
					"select id, name, jerseynumber,gamesplayed,goalsscored from football join stats on  football.id = stats.id ");
			ResultSet rs = prd.executeQuery();
			while (rs.next()) {
				Football football = new Football();
				football.setId(rs.getInt(1));
				football.setName(rs.getString(2));
				football.setJerseynumber(rs.getString(3));
				football.setGamesplayed(rs.getString(4));
				football.setGoalsscored(rs.getString(5));
				data.add(football);
			}
			return data;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public String deletebyname(String id) throws ClassNotFoundException {
		try {
			Football football = new Football();
			if (football == null)
				return "Error with delete data";
			else {
				Class.forName("org.hsqldb.jdbcDriver");
				Connection con = (Connection) DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/onedb", "SA",
						"");
				PreparedStatement fprd = con.prepareStatement("DELETE FROM FOOTBALL where id = ?");
				fprd.setInt(1, Integer.parseInt(id));
				fprd.executeUpdate();

				PreparedStatement fprd1 = con.prepareStatement("DELETE FROM STATS where id = ?");
				fprd1.setInt(1, Integer.parseInt(id));
				fprd1.executeUpdate();

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "Error with delete data";
	}

	public String deleteallfootball() throws ClassNotFoundException {
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			Connection con = (Connection) DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/onedb", "SA", "");
			PreparedStatement fprd = con.prepareStatement("TRUNCATE TABLE FOOTBALL RESTART IDENTITY AND COMMIT");
			fprd.executeUpdate();
			PreparedStatement spred = con.prepareStatement("TRUNCATE TABLE STATS RESTART IDENTITY AND COMMIT");
			spred.executeUpdate();
			return "Delete Successfully";
		} catch (SQLException e) {
			e.printStackTrace();
			return "Error with delete data";
		}
	}

	List<Football> getPlayerName(String name) throws ClassNotFoundException {
		try {
			playersList = new ArrayList<Football>();
			Class.forName("org.hsqldb.jdbcDriver");
			Connection con = (Connection) DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/onedb", "SA", "");

			PreparedStatement fprd = con.prepareStatement("\"SELECT * FROM FOOTBALL where name=?\"");

			PreparedStatement spred = con.prepareStatement(("\"SELECT * FROM STATS where name=?\""));

			fprd.setString(1, name);
			ResultSet rs = fprd.executeQuery();
			while (rs.next()) {
				Football football = new Football();
				football.setName(rs.getString(1));
				football.setJerseynumber(rs.getString(2));
				playersList.add(football);
			}
			fprd.close();
			return playersList;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	String updatefootballdata(String id, String name, String gamesplayed, String goalsscored, String jerseynumber)
			throws ClassNotFoundException {
		try {
			Football football = new Football();
			if (football == null)
				return "Error with delete data";
			else {
				Class.forName("org.hsqldb.jdbcDriver");
				Connection con = (Connection) DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/onedb", "SA",
						"");
				PreparedStatement fprd = con.prepareStatement("UPDATE FOOTBALL SET name=?,jerseynumber=? where id=?");
				fprd.setString(1, name);
				fprd.setInt(2, Integer.parseInt(jerseynumber));
				fprd.setString(3, id);
				fprd.executeUpdate();

				PreparedStatement fprd1 = con
						.prepareStatement("UPDATE STATS SET gamesplayed=?,goalsscored=? where id=?");
				fprd1.setInt(1, Integer.parseInt(gamesplayed));
				fprd1.setInt(2, Integer.parseInt(goalsscored));
				fprd1.setString(3, id);
				fprd1.executeUpdate();

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "Error with Update data";

	}
}
