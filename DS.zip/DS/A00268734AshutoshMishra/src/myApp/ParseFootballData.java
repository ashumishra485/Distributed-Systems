package myApp;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;



public class ParseFootballData {

	private List<Football> list;

	@SuppressWarnings("static-access")
	List<Football> parse(String response) throws XmlPullParserException, IOException {

		list = new ArrayList<Football>();
		XmlPullParser pullParser = XmlPullParserFactory.newInstance().newPullParser();
		pullParser.setInput(new StringReader(response));

		Football football = new Football();
		for (int event = pullParser.getEventType(); event != pullParser.END_DOCUMENT; event = pullParser.next()) {

			if (event == pullParser.START_TAG && pullParser.getName().equals("football")) {
				football = new Football();
			}

			if (event == pullParser.START_TAG && pullParser.getName().equals("id")) {
				event = pullParser.next();
				football.setId(Integer.parseInt(pullParser.getText()));
			}

			if (event == pullParser.START_TAG && pullParser.getName().equals("name")) {
				event = pullParser.next();
				football.setName(pullParser.getText());
			}

			if (event == pullParser.START_TAG && pullParser.getName().equals("gamesplayed")) {
				event = pullParser.next();
				football.setGamesplayed(pullParser.getText());
			}

			if (event == pullParser.START_TAG && pullParser.getName().equals("goalsscored")) {
				event = pullParser.next();
				football.setGoalsscored(pullParser.getText());
			}

			if (event == pullParser.START_TAG && pullParser.getName().equals("jerseynumber")) {
				event = pullParser.next();
				football.setJerseynumber(pullParser.getText());
			}
			if (event == pullParser.END_TAG && pullParser.getName().equals("football")) {
				list.add(football);
			}
		}
		return list;
	}
}