package myApp;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.xmlpull.v1.XmlPullParserException;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.Font;

public class FootballClient {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable table;
	private DefaultTableModel model;
	private List<Football> footballlist;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FootballClient window = new FootballClient();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FootballClient() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 766, 473);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Player Name :");
		lblNewLabel.setBounds(63, 108, 144, 16);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Jersey Number :");
		lblNewLabel_1.setBounds(63, 160, 121, 16);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Games Played :");
		lblNewLabel_2.setBounds(63, 213, 101, 16);
		frame.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Goals Scored :");
		lblNewLabel_3.setBounds(63, 266, 101, 16);
		frame.getContentPane().add(lblNewLabel_3);

		textField = new JTextField();
		textField.setBounds(186, 103, 130, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(186, 155, 130, 26);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setBounds(186, 208, 130, 26);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setBounds(186, 261, 130, 26);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);

		JButton btnNewButton = new JButton("Add Data");

		btnNewButton.setBounds(56, 335, 117, 29);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Delete Data");

		btnNewButton_1.setBounds(234, 335, 117, 29);
		frame.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("Update Data");

		btnNewButton_2.setBounds(393, 335, 117, 29);
		frame.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("View Data");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getData();
			}
		});
		btnNewButton_3.setBounds(569, 335, 117, 29);
		frame.getContentPane().add(btnNewButton_3);

		JLabel lblNewLabel_4 = new JLabel("Player ID : ");
		lblNewLabel_4.setBounds(62, 63, 88, 16);
		frame.getContentPane().add(lblNewLabel_4);

		textField_4 = new JTextField();
		textField_4.setBounds(186, 58, 130, 26);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(328, 59, 432, 264);
		frame.getContentPane().add(scrollPane);

		table = new JTable(new DefaultTableModel(new Object[][] {},
				new String[] { "Player Id", "Player Name", "Jersey Number", "Games Played", "Goals Scored" }));
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_4 = new JButton("Delete All");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("org.hsqldb.jdbcDriver");
					Connection con = (Connection) DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/onedb", "SA", "");
					PreparedStatement fprd = con.prepareStatement("TRUNCATE TABLE FOOTBALL RESTART IDENTITY AND COMMIT");
					fprd.executeUpdate();
					PreparedStatement spred = con.prepareStatement("TRUNCATE TABLE STATS RESTART IDENTITY AND COMMIT");
					spred.executeUpdate();
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
		});
		btnNewButton_4.setBounds(167, 389, 184, 29);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Create Tables");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

					try {
						Class.forName("org.hsqldb.jdbcDriver");
						Connection con = (Connection) DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/onedb", "SA", "");

						Statement stmt = con.createStatement();
						stmt.executeUpdate(
								"CREATE TABLE IF NOT EXISTS FOOTBALL(id INTEGER IDENTITY, name VARCHAR(32) NOT NULL,jerseynumber VARCHAR(32) NOT NULL)");

						stmt.executeUpdate(
								"CREATE TABLE IF NOT EXISTS STATS(id INTEGER IDENTITY, gamesplayed VARCHAR(32) NOT NULL,goalsscored VARCHAR(32) NOT NULL)");

					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			
		});
		btnNewButton_5.setBounds(393, 389, 184, 29);
		frame.getContentPane().add(btnNewButton_5);
		
		JLabel lblNewLabel_5 = new JLabel("FOOTBALL PLAYERS RECORD SYSTEM");
		lblNewLabel_5.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(252, 6, 417, 16);
		frame.getContentPane().add(lblNewLabel_5);

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					URI uri = new URIBuilder().setScheme("http").setHost("localhost").setPort(8080)
							.setPath("/A00268734AshutoshMishra/myApp/footballteam/foottballdata").build();
					System.out.println(uri.toString());

					HttpPost httpPost = new HttpPost(uri);
					httpPost.setHeader("Accept", "application/xml");
					CloseableHttpClient client = HttpClients.createDefault();

					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("name", textField.getText()));
					nameValuePairs.add(new BasicNameValuePair("gamesplayed", textField_2.getText()));
					nameValuePairs.add(new BasicNameValuePair("goalsscored", textField_3.getText()));
					nameValuePairs.add(new BasicNameValuePair("jerseynumber", textField_1.getText()));

					httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					System.out.println("Sending POST request...");
					CloseableHttpResponse response = client.execute(httpPost);

					String result = EntityUtils.toString(response.getEntity());

				} catch (URISyntaxException | IOException ex) {
					ex.printStackTrace();
				}
			}
		});

		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					URI uri = new URIBuilder().setScheme("http").setHost("localhost").setPort(8080)
							.setPath("/A00268734AshutoshMishra/myApp/footballteam/" + textField_4.getText() + "")
							.build();

					HttpDelete httpDelete = new HttpDelete(uri);
					httpDelete.setHeader("Accept", "text/html");
					CloseableHttpClient client = HttpClients.createDefault();

					System.out.println("Sending DELETE request...");
					CloseableHttpResponse response = client.execute(httpDelete);
					String result = EntityUtils.toString(response.getEntity());

				} catch (URISyntaxException | IOException ex) {
					ex.printStackTrace();
				}
			}
		});

		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					URI uri = new URIBuilder().setScheme("http").setHost("localhost").setPort(8080)
							.setPath("/A00268734AshutoshMishra/myApp/footballteam/" + textField_4.getText() + "")
							.build();

					System.out.println(uri.toString());

					HttpPut httpPut = new HttpPut(uri);
					httpPut.setHeader("Accept", "text/html");
					CloseableHttpClient client = HttpClients.createDefault();
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("footballupdate", textField.getText()));
					nameValuePairs.add(new BasicNameValuePair("name", textField.getText()));
					nameValuePairs.add(new BasicNameValuePair("gamesplayed", textField_2.getText()));
					nameValuePairs.add(new BasicNameValuePair("goalsscored", textField_3.getText()));
					nameValuePairs.add(new BasicNameValuePair("jerseynumber", textField_1.getText()));

					httpPut.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					System.out.println("Sending PUT request...");
					CloseableHttpResponse response = client.execute(httpPut);

				} catch (URISyntaxException | IOException ex) {
					ex.printStackTrace();
				}
			}
		});

	}

	public void getData() {
		footballlist = new ArrayList<Football>();
		try {
			URI uri = new URIBuilder().setScheme("http").setHost("localhost").setPort(8080)
					.setPath("/A00268734AshutoshMishra/myApp/footballteam").build();

			System.out.println(uri.toString());

			HttpGet httpReq = new HttpGet(uri);
			httpReq.setHeader("Accept", "application/xml");

			CloseableHttpResponse httpResponse = HttpClients.createDefault().execute(httpReq);

			String result = EntityUtils.toString(httpResponse.getEntity());

			ParseFootballData parsefootball = new ParseFootballData();
			model = (DefaultTableModel) table.getModel();
			model.setRowCount(0);
			System.out.println(result);
			footballlist = parsefootball.parse(result);

			for (Football foo : footballlist) {
				model.addRow(new Object[] { foo.getId(), foo.getName(), foo.getJerseynumber(), foo.getGamesplayed(),
						foo.getGoalsscored() });
			}

		} catch (

		Exception ex) {
			ex.printStackTrace();
		}
	}
}