package myApp;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "football")
@XmlType(propOrder = { "id", "name", "gamesplayed", "goalsscored", "jerseynumber" })
public class Football {

	int id;
	String name, gamesplayed, goalsscored, jerseynumber;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGamesplayed() {
		return gamesplayed;
	}

	public void setGamesplayed(String gamesplayed) {
		this.gamesplayed = gamesplayed;
	}

	public String getGoalsscored() {
		return goalsscored;
	}

	public void setGoalsscored(String goalsscored) {
		this.goalsscored = goalsscored;
	}

	public String getJerseynumber() {
		return jerseynumber;
	}

	public void setJerseynumber(String jerseynumber) {
		this.jerseynumber = jerseynumber;
	}

	@Override
	public String toString() {
		return "Football [id=" + id + ", name=" + name + ", gamesplayed=" + gamesplayed + ", goalsscored=" + goalsscored
				+ ", jerseynumber=" + jerseynumber + "]";
	}
}
